const add = require('./add');
const subtract = require('./subtract');
const multiply = require('./multiply');
const divide = require('./divide');
module.exports = {
  add,
  subtract,
  multiply,
  divide
};
