Problem Statement - 

Calculator provides simple and advance mathematical functions. We can perform four fundamental operations with standard calculator. As a second part of application write a program to perform multiply and divide  functionality. Use TDD approach and support the application with meaningful test cases.