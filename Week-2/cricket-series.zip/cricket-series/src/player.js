const PerformanceCalculator = require('./src/PerformanceCalc')


let players = [];

const addPlayer = (playername, runs, balls) =>{
      let playerPerformance = {
            playername: playername,
            performance: PerformanceCalculator(runs, balls)
      }
      players.push(playerPerformance);
};


const getPlayer = (name) => {
      players.find(({playerName})=>playerName === name)  
}

const getPlayerList = ()=> {
      return players;
}

module.exports = {addPlayer, getPlayer, getPlayerList}